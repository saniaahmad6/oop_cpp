#pragma once
#include <iostream>

class Element {
    virtual void print()=0;
};