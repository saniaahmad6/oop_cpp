Line::Line (double len) : Line{len} {
//     cout<<"Delegating single Constructor"<<endl;
// }