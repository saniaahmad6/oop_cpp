public abstract class Element {
    public abstract void print();
}
